To control Gapminder:
please mouseover year in order to set year
hovering on a country will highlight that country
clicking on a country will highlight that country and all of its region
